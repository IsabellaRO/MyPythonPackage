# Pacote Python

##### Com este pacote python é possível verificar o último commit do [repostório do github da disciplina de Desenvolvimento Aberto do Insper](https://github.com/Insper/dev-aberto).

